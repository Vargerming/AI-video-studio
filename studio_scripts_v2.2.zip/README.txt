Studio Scripts v2.2
-------------------
Files:
  systemd/studio-encode.service  - systemd unit for Linux
  bin/encode-watcher.sh           - watcher script (inotifywait) for Linux
  bin/encode.sh                   - ffmpeg wrapper for encoding
  bin/backup-recordings.sh        - rsync backup to NAS
  windows/backup-recordings.bat   - robocopy backup for Windows
  windows/health-check.bat        - basic health-check for Windows
Installation (Linux):
  unzip studio_scripts_v2.2.zip -d /opt/studio_scripts
  chmod +x /opt/studio_scripts/bin/*.sh
  sudo cp systemd/studio-encode.service /etc/systemd/system/
  sudo systemctl daemon-reload
  sudo systemctl enable --now studio-encode
Installation (Windows):
  copy windows\*.bat to C:\studio\bin\
  create scheduled task via schtasks or Task Scheduler GUI
Edit the scripts to set correct usernames, NAS addresses and paths before use.
